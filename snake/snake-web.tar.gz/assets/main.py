"""
Snake Game - Classic Arcade Game
Built with Python + Pygame, packaged for the web with pygbag.

Controls:
    Arrow Keys / WASD - Move the snake
    Space             - Pause / Resume
    Enter             - Restart after Game Over
    Esc               - Quit (desktop only)

NOTE: This file must be named main.py and use an async main loop so that
pygbag can compile it to WebAssembly and run it in a browser (e.g. via
GitHub Pages). If you just want to run it locally with plain Python, this
file still works the same way.
"""

import asyncio
import pygame
import random
import sys

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CELL_SIZE = 24
GRID_WIDTH = 25
GRID_HEIGHT = 20
SCREEN_WIDTH = CELL_SIZE * GRID_WIDTH
SCREEN_HEIGHT = CELL_SIZE * GRID_HEIGHT + 60  # extra space for the score bar

BASE_SPEED = 8          # starting moves per second
MAX_SPEED = 20          # speed cap
SPEED_STEP_EVERY = 5    # increase speed every N points

# Colors
COLOR_BG = (18, 18, 24)
COLOR_GRID = (28, 28, 36)
COLOR_SNAKE_HEAD = (80, 250, 140)
COLOR_SNAKE_BODY = (46, 184, 105)
COLOR_FOOD = (250, 90, 90)
COLOR_TEXT = (230, 230, 240)
COLOR_TEXT_DIM = (150, 150, 165)
COLOR_PANEL = (24, 24, 32)
COLOR_ACCENT = (90, 200, 250)

UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)


class SnakeGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Snake")
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        self.clock = pygame.time.Clock()

        self.font_large = pygame.font.SysFont("consolas", 48, bold=True)
        self.font_medium = pygame.font.SysFont("consolas", 28, bold=True)
        self.font_small = pygame.font.SysFont("consolas", 18)

        self.high_score = 0
        self.reset()

    # -----------------------------------------------------------------
    # Setup / reset
    # -----------------------------------------------------------------
    def reset(self):
        center = (GRID_WIDTH // 2, GRID_HEIGHT // 2)
        self.snake = [center, (center[0] - 1, center[1]), (center[0] - 2, center[1])]
        self.direction = RIGHT
        self.pending_direction = RIGHT
        self.food = self.spawn_food()
        self.score = 0
        self.game_over = False
        self.paused = False
        self.started = False

    def spawn_food(self):
        while True:
            pos = (random.randint(0, GRID_WIDTH - 1), random.randint(0, GRID_HEIGHT - 1))
            if pos not in self.snake:
                return pos

    # -----------------------------------------------------------------
    # Input handling
    # -----------------------------------------------------------------
    def handle_input(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()

                if self.game_over:
                    if event.key == pygame.K_RETURN:
                        self.reset()
                    continue

                if event.key == pygame.K_SPACE:
                    self.paused = not self.paused
                    continue

                new_dir = None
                if event.key in (pygame.K_UP, pygame.K_w):
                    new_dir = UP
                elif event.key in (pygame.K_DOWN, pygame.K_s):
                    new_dir = DOWN
                elif event.key in (pygame.K_LEFT, pygame.K_a):
                    new_dir = LEFT
                elif event.key in (pygame.K_RIGHT, pygame.K_d):
                    new_dir = RIGHT

                if new_dir:
                    # Prevent reversing directly into itself
                    opposite = (-self.direction[0], -self.direction[1])
                    if new_dir != opposite:
                        self.pending_direction = new_dir
                        self.started = True

    # -----------------------------------------------------------------
    # Update
    # -----------------------------------------------------------------
    def current_speed(self):
        bonus = self.score // SPEED_STEP_EVERY
        return min(BASE_SPEED + bonus, MAX_SPEED)

    def update(self):
        if self.game_over or self.paused or not self.started:
            return

        self.direction = self.pending_direction
        head_x, head_y = self.snake[0]
        dx, dy = self.direction
        new_head = (head_x + dx, head_y + dy)

        # Wall collision
        if not (0 <= new_head[0] < GRID_WIDTH and 0 <= new_head[1] < GRID_HEIGHT):
            self.end_game()
            return

        # Self collision
        if new_head in self.snake:
            self.end_game()
            return

        self.snake.insert(0, new_head)

        if new_head == self.food:
            self.score += 1
            self.high_score = max(self.high_score, self.score)
            self.food = self.spawn_food()
        else:
            self.snake.pop()

    def end_game(self):
        self.game_over = True
        self.high_score = max(self.high_score, self.score)

    # -----------------------------------------------------------------
    # Drawing
    # -----------------------------------------------------------------
    def draw_grid(self):
        for x in range(GRID_WIDTH):
            for y in range(GRID_HEIGHT):
                if (x + y) % 2 == 0:
                    rect = pygame.Rect(x * CELL_SIZE, y * CELL_SIZE + 60, CELL_SIZE, CELL_SIZE)
                    pygame.draw.rect(self.screen, COLOR_GRID, rect)

    def draw_snake(self):
        for i, (x, y) in enumerate(self.snake):
            rect = pygame.Rect(x * CELL_SIZE + 1, y * CELL_SIZE + 60 + 1, CELL_SIZE - 2, CELL_SIZE - 2)
            color = COLOR_SNAKE_HEAD if i == 0 else COLOR_SNAKE_BODY
            pygame.draw.rect(self.screen, color, rect, border_radius=6)

    def draw_food(self):
        x, y = self.food
        rect = pygame.Rect(x * CELL_SIZE + 3, y * CELL_SIZE + 60 + 3, CELL_SIZE - 6, CELL_SIZE - 6)
        pygame.draw.rect(self.screen, COLOR_FOOD, rect, border_radius=8)

    def draw_top_bar(self):
        pygame.draw.rect(self.screen, COLOR_PANEL, (0, 0, SCREEN_WIDTH, 60))
        score_surf = self.font_medium.render(f"Score: {self.score}", True, COLOR_TEXT)
        self.screen.blit(score_surf, (16, 15))

        high_surf = self.font_small.render(f"Best: {self.high_score}", True, COLOR_ACCENT)
        self.screen.blit(high_surf, (SCREEN_WIDTH - high_surf.get_width() - 16, 21))

    def draw_center_message(self, title, subtitle=None, title_color=COLOR_TEXT):
        overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
        overlay.fill((10, 10, 14, 180))
        self.screen.blit(overlay, (0, 0))

        title_surf = self.font_large.render(title, True, title_color)
        title_rect = title_surf.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 20))
        self.screen.blit(title_surf, title_rect)

        if subtitle:
            sub_surf = self.font_small.render(subtitle, True, COLOR_TEXT_DIM)
            sub_rect = sub_surf.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 30))
            self.screen.blit(sub_surf, sub_rect)

    def draw(self):
        self.screen.fill(COLOR_BG)
        self.draw_grid()
        self.draw_food()
        self.draw_snake()
        self.draw_top_bar()

        if not self.started and not self.game_over:
            self.draw_center_message("SNAKE", "Press an arrow key or WASD to start")
        elif self.paused and not self.game_over:
            self.draw_center_message("PAUSED", "Press SPACE to resume", title_color=COLOR_ACCENT)
        elif self.game_over:
            self.draw_center_message(
                "GAME OVER",
                f"Score: {self.score}   Best: {self.high_score}   -   Press ENTER to restart",
                title_color=COLOR_FOOD,
            )

        pygame.display.flip()


async def main():
    game = SnakeGame()
    while True:
        game.handle_input()
        game.update()
        game.draw()
        game.clock.tick(game.current_speed())
        await asyncio.sleep(0)  # required by pygbag so the browser can breathe


if __name__ == "__main__":
    asyncio.run(main())
